﻿using CMCS_API.Controllers;
using CMCS_API.Data;
using CMCS_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMCS_API.Tests
{
    public class ControllerTests
    {
        // This makes a fake empty database in memory.
        // Every test calls it, so every test starts fresh.
        private CMCS_APIContext MakeDatabase()
        {
            var options = new DbContextOptionsBuilder<CMCS_APIContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            var db = new CMCS_APIContext(options);
            return db;
        }

        // =============== CLAIM TESTS ===============

        // SUCCESS: submitting a claim works
        [Fact]
        public async Task Submit_GoodClaim_ReturnsCreated()
        {
            // set up
            var db = MakeDatabase();
            var controller = new ClaimController(db);
            var claim = new Claim();
            claim.LecturerID = 1;
            claim.HoursWorked = 8;
            claim.HourlyRate = 200;

            // run
            var result = await controller.Submit(claim);

            // check
            var response = Assert.IsType<ObjectResult>(result);
            Assert.Equal(201, response.StatusCode);
            Assert.Equal(1600, claim.TotalAmount);
            Assert.Equal("Pending", claim.ClaimStatus);
        }

        // SUCCESS: getting a claim that exists
        [Fact]
        public async Task GetOne_ClaimExists_ReturnsOk()
        {
            var db = MakeDatabase();
            var claim = new Claim();
            claim.ClaimID = 1;
            db.Claims.Add(claim);
            await db.SaveChangesAsync();
            var controller = new ClaimController(db);

            var result = await controller.GetOne(1);

            Assert.IsType<OkObjectResult>(result);
        }

        // FAILURE: getting a claim that does not exist
        [Fact]
        public async Task GetOne_ClaimMissing_ReturnsNotFound()
        {
            var db = MakeDatabase();
            var controller = new ClaimController(db);

            var result = await controller.GetOne(999);

            Assert.IsType<NotFoundResult>(result);
        }

        // SUCCESS: verifying a claim
        [Fact]
        public async Task Verify_ClaimExists_StatusBecomesVerified()
        {
            var db = MakeDatabase();
            var claim = new Claim();
            claim.ClaimID = 1;
            claim.ClaimStatus = "Pending";
            db.Claims.Add(claim);
            await db.SaveChangesAsync();
            var controller = new ClaimController(db);

            var result = await controller.Verify(1);

            Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Verified", claim.ClaimStatus);
        }

        // FAILURE: verifying a claim that does not exist
        [Fact]
        public async Task Verify_ClaimMissing_ReturnsNotFound()
        {
            var db = MakeDatabase();
            var controller = new ClaimController(db);

            var result = await controller.Verify(999);

            Assert.IsType<NotFoundResult>(result);
        }

        // SUCCESS: approving a claim
        [Fact]
        public async Task Approve_ClaimExists_StatusBecomesApproved()
        {
            var db = MakeDatabase();
            var claim = new Claim();
            claim.ClaimID = 1;
            claim.ClaimStatus = "Verified";
            db.Claims.Add(claim);
            await db.SaveChangesAsync();
            var controller = new ClaimController(db);

            var result = await controller.Approve(1);

            Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Approved", claim.ClaimStatus);
        }

        // FAILURE: approving a claim that does not exist
        [Fact]
        public async Task Approve_ClaimMissing_ReturnsNotFound()
        {
            var db = MakeDatabase();
            var controller = new ClaimController(db);

            var result = await controller.Approve(999);

            Assert.IsType<NotFoundResult>(result);
        }

        // SUCCESS: rejecting a claim
        [Fact]
        public async Task Reject_ClaimExists_StatusBecomesRejected()
        {
            var db = MakeDatabase();
            var claim = new Claim();
            claim.ClaimID = 1;
            claim.ClaimStatus = "Pending";
            db.Claims.Add(claim);
            await db.SaveChangesAsync();
            var controller = new ClaimController(db);

            var result = await controller.Reject(1);

            Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Rejected", claim.ClaimStatus);
        }

        // SUCCESS: deleting a claim
        [Fact]
        public async Task Delete_ClaimExists_ReturnsNoContent()
        {
            var db = MakeDatabase();
            var claim = new Claim();
            claim.ClaimID = 1;
            db.Claims.Add(claim);
            await db.SaveChangesAsync();
            var controller = new ClaimController(db);

            var result = await controller.Delete(1);

            Assert.IsType<NoContentResult>(result);
        }

        // FAILURE: deleting a claim that does not exist
        [Fact]
        public async Task Delete_ClaimMissing_ReturnsNotFound()
        {
            var db = MakeDatabase();
            var controller = new ClaimController(db);

            var result = await controller.Delete(999);

            Assert.IsType<NotFoundResult>(result);
        }

        // =============== LOGIN TESTS ===============

        // SUCCESS: correct email and password
        [Fact]
        public async Task Login_CorrectDetails_ReturnsOk()
        {
            var db = MakeDatabase();
            var lecturer = new Lecturer();
            lecturer.LecturerID = 1;
            lecturer.FullName = "John Smith";
            lecturer.Email = "john@college.com";
            lecturer.Password = "1234";
            db.Lecturers.Add(lecturer);
            await db.SaveChangesAsync();
            var controller = new AuthController(db);

            var login = new Lecturer();
            login.Email = "john@college.com";
            login.Password = "1234";
            var result = await controller.Login(login);

            Assert.IsType<OkObjectResult>(result);
        }

        // FAILURE: wrong password
        [Fact]
        public async Task Login_WrongPassword_ReturnsUnauthorized()
        {
            var db = MakeDatabase();
            var lecturer = new Lecturer();
            lecturer.LecturerID = 1;
            lecturer.FullName = "John Smith";
            lecturer.Email = "john@college.com";
            lecturer.Password = "1234";
            db.Lecturers.Add(lecturer);
            await db.SaveChangesAsync();
            var controller = new AuthController(db);

            var login = new Lecturer();
            login.Email = "john@college.com";
            login.Password = "wrongpassword";
            var result = await controller.Login(login);

            Assert.IsType<UnauthorizedResult>(result);
        }

        // FAILURE: email that is not in the database
        [Fact]
        public async Task Login_UnknownEmail_ReturnsUnauthorized()
        {
            var db = MakeDatabase();
            var controller = new AuthController(db);

            var login = new Lecturer();
            login.Email = "nobody@college.com";
            login.Password = "1234";
            var result = await controller.Login(login);

            Assert.IsType<UnauthorizedResult>(result);
        }

        // =============== LECTURER TESTS ===============

        // SUCCESS: registering a lecturer
        [Fact]
        public async Task Register_NewLecturer_ReturnsCreated()
        {
            var db = MakeDatabase();
            var controller = new LecturerController(db);
            var lecturer = new Lecturer();
            lecturer.FullName = "Test Lecturer";
            lecturer.Email = "test@college.com";
            lecturer.Password = "abc";

            var result = await controller.Register(lecturer);

            var response = Assert.IsType<ObjectResult>(result);
            Assert.Equal(201, response.StatusCode);
        }

        // SUCCESS: viewing a profile that exists
        [Fact]
        public async Task ViewProfile_LecturerExists_ReturnsOk()
        {
            var db = MakeDatabase();
            var lecturer = new Lecturer();
            lecturer.LecturerID = 1;
            lecturer.FullName = "John Smith";
            lecturer.Email = "john@college.com";
            lecturer.Password = "1234";
            db.Lecturers.Add(lecturer);
            await db.SaveChangesAsync();
            var controller = new LecturerController(db);

            var result = await controller.ViewProfile(1);

            Assert.IsType<OkObjectResult>(result);
        }

        // FAILURE: viewing a profile that does not exist
        [Fact]
        public async Task ViewProfile_LecturerMissing_ReturnsNotFound()
        {
            var db = MakeDatabase();
            var controller = new LecturerController(db);

            var result = await controller.ViewProfile(999);

            Assert.IsType<NotFoundResult>(result);
        }

        // =============== DOCUMENT TESTS ===============

        // SUCCESS: uploading a file to a claim that exists
        [Fact]
        public async Task Upload_GoodFile_ReturnsCreated()
        {
            var db = MakeDatabase();
            var claim = new Claim();
            claim.ClaimID = 1;
            db.Claims.Add(claim);
            await db.SaveChangesAsync();
            var controller = new DocumentsController(db);

            // make a pretend file
            var stream = new MemoryStream(new byte[] { 1, 2, 3 });
            var file = new FormFile(stream, 0, stream.Length, "file", "timetable.pdf");

            var result = await controller.Upload(1, file);

            var response = Assert.IsType<ObjectResult>(result);
            Assert.Equal(201, response.StatusCode);
        }

        // FAILURE: uploading to a claim that does not exist
        [Fact]
        public async Task Upload_ClaimMissing_ReturnsNotFound()
        {
            var db = MakeDatabase();
            var controller = new DocumentsController(db);

            var stream = new MemoryStream(new byte[] { 1, 2, 3 });
            var file = new FormFile(stream, 0, stream.Length, "file", "timetable.pdf");

            var result = await controller.Upload(999, file);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        // FAILURE: uploading with no file
        [Fact]
        public async Task Upload_NoFile_ReturnsBadRequest()
        {
            var db = MakeDatabase();
            var controller = new DocumentsController(db);

            var result = await controller.Upload(1, null);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        // SUCCESS: deleting a document
        [Fact]
        public async Task DeleteDoc_DocExists_ReturnsNoContent()
        {
            var db = MakeDatabase();
            var doc = new Supporting_Document();
            doc.DocumentID = 1;
            doc.ClaimID = 1;
            doc.FileName = "timetable.pdf";
            db.Supporting_Document.Add(doc);
            await db.SaveChangesAsync();
            var controller = new DocumentsController(db);

            var result = await controller.DeleteDoc(1);

            Assert.IsType<NoContentResult>(result);
        }

        // FAILURE: deleting a document that does not exist
        [Fact]
        public async Task DeleteDoc_DocMissing_ReturnsNotFound()
        {
            var db = MakeDatabase();
            var controller = new DocumentsController(db);

            var result = await controller.DeleteDoc(999);

            Assert.IsType<NotFoundResult>(result);
        }
    }
}
