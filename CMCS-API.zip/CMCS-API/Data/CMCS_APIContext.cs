﻿using CMCS_API.Models;
using Microsoft.EntityFrameworkCore;

namespace CMCS_API.Data
{
    public class CMCS_APIContext : DbContext
    {
        public CMCS_APIContext(DbContextOptions<CMCS_APIContext> options) : base(options)
        {
        }

        // DbSets - each one becomes a table in (localdb)\MSSQLLocalDB
        public DbSet<Lecturer> Lecturers { get; set; }
        public DbSet<Claim> Claims { get; set; }
        public DbSet<Supporting_Document> Supporting_Document { get; set; }
        public DbSet<Coordinator> Coordinators { get; set; }
        public DbSet<Manager> Managers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed lecturers
            modelBuilder.Entity<Lecturer>().HasData(
                new Lecturer { LecturerID = 1, FullName = "John Smith", Email = "john.smith@college.com", Password = "132435" },
                new Lecturer { LecturerID = 2, FullName = "Sarah Johnson", Email = "sarah.j@college.com", Password = "67890" },
                new Lecturer { LecturerID = 3, FullName = "Peter Molefe", Email = "p.molefe@college.com", Password = "12345" }
            );

            // Seed claims (LecturerID must match a seeded lecturer)
            modelBuilder.Entity<Claim>().HasData(
                new Claim
                {
                    ClaimID = 1,
                    LecturerID = 1,
                    HoursWorked = 10,
                    HourlyRate = 300,
                    TotalAmount = 3000,
                    ClaimStatus = "Pending"
                },
                new Claim
                {
                    ClaimID = 2,
                    LecturerID = 2,
                    HoursWorked = 5,
                    HourlyRate = 250,
                    TotalAmount = 1250,
                    ClaimStatus = "Verified"
                }
            );

            // Seed supporting documents (ClaimID must match a seeded claim)
            modelBuilder.Entity<Supporting_Document>().HasData(
                new Supporting_Document { DocumentID = 1, ClaimID = 1, FileName = "timetable.pdf" },
                new Supporting_Document { DocumentID = 2, ClaimID = 2, FileName = "attendance.pdf" }
            );

            // Seed coordinator and manager
            modelBuilder.Entity<Coordinator>().HasData(
                new Coordinator { CoordinatorID = 1, FullName = "Coordinator One", Email = "coordinator@college.com" }
            );

            modelBuilder.Entity<Manager>().HasData(
                new Manager { ManagerID = 1, FullName = "Manager One", Email = "manager@college.com" }
            );
        }
    }
}