﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace CMCS_API.Migrations
{
    /// <inheritdoc />
    public partial class SeedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Claims",
                columns: new[] { "ClaimID", "ClaimStatus", "HourlyRate", "HoursWorked", "LecturerID", "TotalAmount" },
                values: new object[,]
                {
                    { 1, "Pending", 300m, 10, 1, 3000m },
                    { 2, "Verified", 250m, 5, 2, 1250m }
                });

            migrationBuilder.InsertData(
                table: "Coordinators",
                columns: new[] { "CoordinatorID", "Email", "FullName" },
                values: new object[] { 1, "coordinator@college.com", "Coordinator One" });

            migrationBuilder.InsertData(
                table: "Lecturers",
                columns: new[] { "LecturerID", "Email", "FullName", "Password" },
                values: new object[,]
                {
                    { 1, "john.smith@college.com", "John Smith", "132435" },
                    { 2, "sarah.j@college.com", "Sarah Johnson", "67890" },
                    { 3, "p.molefe@college.com", "Peter Molefe", "12345" }
                });

            migrationBuilder.InsertData(
                table: "Managers",
                columns: new[] { "ManagerID", "Email", "FullName" },
                values: new object[] { 1, "manager@college.com", "Manager One" });

            migrationBuilder.InsertData(
                table: "Supporting_Document",
                columns: new[] { "DocumentID", "ClaimID", "FileName" },
                values: new object[,]
                {
                    { 1, 1, "timetable.pdf" },
                    { 2, 2, "attendance.pdf" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Claims",
                keyColumn: "ClaimID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Claims",
                keyColumn: "ClaimID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Coordinators",
                keyColumn: "CoordinatorID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Lecturers",
                keyColumn: "LecturerID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Lecturers",
                keyColumn: "LecturerID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Lecturers",
                keyColumn: "LecturerID",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Managers",
                keyColumn: "ManagerID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Supporting_Document",
                keyColumn: "DocumentID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Supporting_Document",
                keyColumn: "DocumentID",
                keyValue: 2);
        }
    }
}
