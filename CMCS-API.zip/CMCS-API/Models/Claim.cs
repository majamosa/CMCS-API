﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CMCS_API.Models
{
    public class Claim
    {
        public int ClaimID { get; set; }
        public int LecturerID { get; set; }
        public int HoursWorked { get; set; }
        [Column(TypeName ="decimal(18,2)")]
        public decimal HourlyRate { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }
        public string ClaimStatus { get; set; } = "pending";
    }
}
