﻿namespace CMCS_API.Models
{
    public class Manager
    {
        
        public int ManagerID { get; set; }
        public string FullName { get; set; } = null!;
        public string Email { get; set; } = null!;
    }
}
