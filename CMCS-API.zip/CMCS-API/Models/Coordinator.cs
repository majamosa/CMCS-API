﻿namespace CMCS_API.Models
{
    public class Coordinator
    {
        public int CoordinatorID { get; set; }
        public string FullName { get; set; } = null!;
        public string Email { get; set; } = null!;
    }
}
