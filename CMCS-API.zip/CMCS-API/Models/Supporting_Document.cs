﻿using System.ComponentModel.DataAnnotations;

namespace CMCS_API.Models
{
    public class Supporting_Document
    {
        [Key]
        public int DocumentID { get; set; }
        public int ClaimID { get; set; }
        public string FileName { get; set; } = null!;
    }
}
