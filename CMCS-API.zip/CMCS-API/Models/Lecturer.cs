﻿namespace CMCS_API.Models
{
    public class Lecturer
    {
        public int LecturerID { get; set; }
        public string Password { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string FullName { get; set; } = null!;

    }
}
