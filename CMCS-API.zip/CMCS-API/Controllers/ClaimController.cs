﻿using CMCS_API.Data;
using CMCS_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMCS_API.Controllers
{
    [Route("api/claims")]
    [ApiController]
    public class ClaimController : ControllerBase
    {
        private readonly CMCS_APIContext _db;

        public ClaimController(CMCS_APIContext db)
        {
            _db = db;
        }

        // DELETE the old "public static List<Claim> claims = ..." block

        [HttpGet]
        public async Task<IActionResult> GetClaims()
            => Ok(await _db.Claims.ToListAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> GetOne(int id)
        {
            var c = await _db.Claims.FindAsync(id);
            if (c == null) return NotFound();
            return Ok(c);
        }

        [HttpPost]
        public async Task<IActionResult> Submit([FromBody] Claim c)
        {
            c.TotalAmount = c.HoursWorked * c.HourlyRate;
            c.ClaimStatus = "Pending";
            _db.Claims.Add(c);
            await _db.SaveChangesAsync();
            return StatusCode(201, c);
        }

        [HttpPut("{id}/verify")]
        public async Task<IActionResult> Verify(int id)
        {
            var c = await _db.Claims.FindAsync(id);
            if (c == null) return NotFound();
            c.ClaimStatus = "Verified";
            await _db.SaveChangesAsync();
            return Ok(c);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Claim update)
        {
            var c = await _db.Claims.FindAsync(id);
            if (c == null) return NotFound();

            c.HoursWorked = update.HoursWorked;
            c.HourlyRate = update.HourlyRate;
            c.TotalAmount = c.HoursWorked * c.HourlyRate;
            await _db.SaveChangesAsync();
            return Ok(c);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var c = await _db.Claims.FindAsync(id);
            if (c == null) return NotFound();

            _db.Claims.Remove(c);
            await _db.SaveChangesAsync();
            return NoContent();
        }

        [HttpGet("pending")]
        public async Task<IActionResult> Pending()
            => Ok(await _db.Claims.Where(x => x.ClaimStatus == "Pending").ToListAsync());

        [HttpGet("verified")]
        public async Task<IActionResult> Verified()
            => Ok(await _db.Claims.Where(x => x.ClaimStatus == "Verified").ToListAsync());

        [HttpPut("{id}/reject")]
        public async Task<IActionResult> Reject(int id)
        {
            var c = await _db.Claims.FindAsync(id);
            if (c == null) return NotFound();
            c.ClaimStatus = "Rejected";
            await _db.SaveChangesAsync();
            return Ok(c);
        }

        [HttpPut("{id}/approve")]
        public async Task<IActionResult> Approve(int id)
        {
            var c = await _db.Claims.FindAsync(id);
            if (c == null) return NotFound();
            c.ClaimStatus = "Approved";
            await _db.SaveChangesAsync();
            return Ok(c);
        }
    }
}