﻿using CMCS_API.Data;
using CMCS_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMCS_API.Controllers
{
    [Route("api/lecturers")]
    [ApiController]
    public class LecturerController : ControllerBase
    {
        private readonly CMCS_APIContext _db;

        public LecturerController(CMCS_APIContext db)
        {
            _db = db;
        }

        // GET /api/lecturers
        [HttpGet]
        public async Task<IActionResult> GetAllLecturers()
            => Ok(await _db.Lecturers.ToListAsync());

        // POST /api/lecturers/register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Lecturer l)
        {
            l.LecturerID = 0; // let SQL Server generate the ID
            _db.Lecturers.Add(l);
            await _db.SaveChangesAsync();
            return StatusCode(201, l);
        }

        // GET /api/lecturers/profile/{id}
        [HttpGet("profile/{id}")]
        public async Task<IActionResult> ViewProfile(int id)
        {
            var lec = await _db.Lecturers.FindAsync(id);
            if (lec == null) return NotFound();
            return Ok(lec);
        }

        // PUT /api/lecturers/profile/{id}
        [HttpPut("profile/{id}")]
        public async Task<IActionResult> UpdateProfile(int id, [FromBody] Lecturer update)
        {
            var lec = await _db.Lecturers.FindAsync(id);
            if (lec == null) return NotFound();

            lec.FullName = update.FullName;
            lec.Email = update.Email;
            await _db.SaveChangesAsync();
            return Ok(lec);
        }
    }
}