﻿using CMCS_API.Data;
using CMCS_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMCS_API.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly CMCS_APIContext _db;

        public AuthController(CMCS_APIContext db)
        {
            _db = db;
        }

        // POST /api/auth/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Lecturer login)
        {
            var found = await _db.Lecturers.FirstOrDefaultAsync(
                x => x.Email == login.Email && x.Password == login.Password);

            if (found == null) return Unauthorized();
            return Ok(found);
        }
    }
}