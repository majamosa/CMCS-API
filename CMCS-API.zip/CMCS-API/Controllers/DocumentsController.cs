﻿using CMCS_API.Data;
using CMCS_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CMCS_API.Controllers
{
    [Route("api")]
    [ApiController]
    public class DocumentsController : ControllerBase
    {
        private readonly CMCS_APIContext _db;

        public DocumentsController(CMCS_APIContext db)
        {
            _db = db;
        }

        // POST /api/claims/{id}/documents
        [HttpPost("claims/{id}/documents")]
        public async Task<IActionResult> Upload(int id, IFormFile file)
        {
            if (file == null || file.Length == 0) return BadRequest("No file uploaded.");

            var claimExists = await _db.Claims.AnyAsync(c => c.ClaimID == id);
            if (!claimExists) return NotFound("Claim not found.");

            var d = new Supporting_Document { ClaimID = id, FileName = file.FileName };
            _db.Supporting_Document.Add(d);
            await _db.SaveChangesAsync();
            return StatusCode(201, d);
        }

        // GET /api/claims/{id}/documents
        [HttpGet("claims/{id}/documents")]
        public async Task<IActionResult> ViewDocs(int id)
            => Ok(await _db.Supporting_Document.Where(x => x.ClaimID == id).ToListAsync());

        // DELETE /api/documents/{id}
        [HttpDelete("documents/{id}")]
        public async Task<IActionResult> DeleteDoc(int id)
        {
            var d = await _db.Supporting_Document.FindAsync(id);
            if (d == null) return NotFound();

            _db.Supporting_Document.Remove(d);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}